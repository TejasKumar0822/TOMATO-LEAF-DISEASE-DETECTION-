const imageInput = document.getElementById("imageInput");
const preview = document.getElementById("preview");

imageInput.addEventListener("change", function () {

    const file = imageInput.files[0];

    if(file){
        preview.src = URL.createObjectURL(file);
    }

});

async function sendToBackend(){

    const file = imageInput.files[0];

    if(!file){
        alert("Please upload an image first!");
        return;
    }

    const formData = new FormData();
    formData.append("image", file);

    try{

        const response = await fetch("http://127.0.0.1:5000/predict",{
            method:"POST",
            body:formData
        });

        const data = await response.json();

        localStorage.setItem("predictedDisease", data.disease);
        localStorage.setItem("confidence", data.confidence);
        localStorage.setItem("treatment", data.treatment);

        window.location.href="result.html";

    }catch(error){

        alert("Backend connection error!");
        console.log(error);

    }

}